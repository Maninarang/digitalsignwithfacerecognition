import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-newsignpdf',
  templateUrl: './newsignpdf.component.html',
  styleUrls: ['./newsignpdf.component.css']
})
export class NewsignpdfComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
