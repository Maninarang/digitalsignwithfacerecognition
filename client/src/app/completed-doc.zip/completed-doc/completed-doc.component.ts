import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-completed-doc',
  templateUrl: './completed-doc.component.html',
  styleUrls: ['./completed-doc.component.css']
})
export class CompletedDocComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
