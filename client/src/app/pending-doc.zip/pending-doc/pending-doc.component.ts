import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pending-doc',
  templateUrl: './pending-doc.component.html',
  styleUrls: ['./pending-doc.component.css']
})
export class PendingDocComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
